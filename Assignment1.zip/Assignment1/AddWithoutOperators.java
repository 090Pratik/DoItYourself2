
//q14 How to add two numbers without using the arithmetic operators in Java? 

import java.util.*;

class AddWithoutOperators 
{

    static int add(int a, int b) 
	{
	for (int i = 1; i <= b; i++) 
	
	{
	a++;
	}
	return a;
    }

     public static void main(String[] args) 
     {

	int a = add(20, 22); // first number is 20 and second number is 22 , for loop will start
	System.out.print(a); // from 1 and move till 22 and the value of a is incremented 22 times
	
     }

}


