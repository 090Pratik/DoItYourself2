


// q6 Java Program to swap two numbers
// without using third variable approch 3


import java.io.*;

class Swap3 {
	public static void main(String[] args)
	{
		int x = 10;
		int y = 5;

		// Code to swap 'x' and 'y'
		x = x * y; // x now becomes 50
		y = x / y; // y becomes 10
		x = x / y; // x becomes 5

		System.out.println("After swaping:"
						+ " x = " + x + ", y = " + y);
	}
}


