



// q5 Java Program to swap two numbers without using third variable second approch

import java.io.*;

class Swap2 {

	public static void main(String a[])
	{
		int x = 10;
		int y = 5;
		x = x + y;
		y = x - y;
		x = x - y;
		System.out.println("After swapping:"
						+ " x = " + x + ", y = " + y);
	}
}


