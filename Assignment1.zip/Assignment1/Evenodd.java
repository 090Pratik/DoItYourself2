// Assignment1    date 22/2/22

//q1 check the number if it is even or odd

import java.util.Scanner;

class Evenodd
{
    public static void main (String args[])
	{
	  Scanner sc = new Scanner(System.in);
	  System.out.println("Enter the number");
	  int n;
	  n = sc.nextInt();
	  
	  if( n % 2 == 0)
	  {
	    System.out.println("Given number is even");
	  }
      else
      {
        System.out.println("given number is odd");
      }
  
    }
}	
	   
	    