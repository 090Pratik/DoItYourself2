


import java.util.Scanner; 
 
 class Numberdigits 
{  
    public static void main(String args[])  
    {  
       int n, temp, digit, count=0;  
 
       Scanner sc = new Scanner(System.in);  
       System.out.print("Enter any number: ");  
 
       n=sc.nextInt();  
 
       temp=n;  
       //the loop determines the position of the digit  
         while(n>0)  
         {  
           n=n/10;  
  
           count++;  
         }  
		 
    //the loop breaks the number into digits  
     while(temp > 0)  
     {  
    //finding the remainder  
     digit=temp%10;  
    //prints the position and digit  
    System.out.println("Digit at place "+count+" is: "+digit);  
    temp=temp/10;  
    //decrements the digit by 1  
    count--;  
}  
}  
}  