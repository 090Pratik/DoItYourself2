

//q4 Swap two numbers without using third variable approach 1.



 class Swap
 {

	public static void main(String[] args)
	{

		int x = 10, y = 20;

		System.out.println("Before Swap");
		System.out.println("x = " + x);
		System.out.println("y = " + y);

		int temp = x;
		x = y;
		y = temp;

		System.out.println("After swap");
		System.out.println("x = " + x);
		System.out.println("y = " + y);
	}
}
