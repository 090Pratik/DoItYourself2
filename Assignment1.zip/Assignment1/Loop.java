//q9 Write a Java Program to Print 1 To 10 Without Using Loop. 



import java.io.*;

class Loop 
{
	public static void main(String[] args)
	{
		printNos(1, 100);
	}
	
	public static void printNos(int initial, int last)
	{
		if (initial <= last) {
			System.out.print(initial + " ");
			printNos(initial + 1, last);
		}
	}
}
